import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CaesarSimple {

    static final String ALPHABET = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя";
    static final int N = ALPHABET.length();

    static final double[] RU_FREQ = {
            8.01, 1.59, 4.54, 1.70, 2.98, 8.45, 0.04, 0.94, 1.65, 7.35, 1.21,
            3.49, 4.40, 3.21, 6.70, 10.97, 2.81, 4.73, 5.47, 6.26, 2.62, 0.26,
            0.97, 0.48, 1.44, 0.73, 0.36, 0.04, 1.90, 1.74, 0.32, 0.64, 2.01
    };

    static String shift(String text, int key) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) {
            int idx = ALPHABET.indexOf(Character.toLowerCase(c));
            if (idx < 0) {
                sb.append(c);
                continue;
            }
            char res = ALPHABET.charAt(Math.floorMod(idx + key, N));
            sb.append(Character.isUpperCase(c) ? Character.toUpperCase(res) : res);
        }
        return sb.toString();
    }

    static void processFile(Path in, Path out, int key) throws IOException {
        try (Stream<String> lines = Files.lines(in, StandardCharsets.UTF_8)) {
            Files.write(out, (Iterable<String>) lines.map(line -> shift(line, key))::iterator,
                    StandardCharsets.UTF_8);
        }
    }

    static void checkInput(Path in) {
        if (!Files.exists(in)) {
            throw new IllegalArgumentException("Файл не найден: " + in.toAbsolutePath());
        }
        if (!Files.isRegularFile(in)) {
            throw new IllegalArgumentException("Это не файл: " + in);
        }
    }

    static Path askPath(Scanner sc, String question) {
        System.out.print(question);
        return Path.of(sc.nextLine().trim().replace("\"", ""));
    }

    static int askKey(Scanner sc) {
        System.out.print("Ключ (число): ");
        String s = sc.nextLine().trim();
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("ключ может быть уелым числом " + s);
        }
    }

    static int statisticalKey(Path in) throws IOException {
        long[] counts = new long[N];
        try (Stream<String> lines = Files.lines(in, StandardCharsets.UTF_8)) {
            lines.forEach(line -> {
                for (char c : line.toLowerCase().toCharArray()) {
                    int i = ALPHABET.indexOf(c);
                    if (i >= 0) {
                        counts[i]++;
                    }
                }
            });
        }
        long total = 0;
        for (long c : counts) {
            total += c;
        }
        if (total == 0) {
            throw new IllegalArgumentException("В файле нет русских букв");
        }
        int bestKey = 0;
        double bestScore = Double.MAX_VALUE;
        for (int key = 0; key < N; key++) {
            double score = 0;
            for (int j = 0; j < N; j++) {
                double actual = 100.0 * counts[(j + key) % N] / total;
                score += Math.pow(actual - RU_FREQ[j], 2);
            }
            if (score < bestScore) {
                bestScore = score;
                bestKey = key;
            }
        }
        return bestKey;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in, StandardCharsets.UTF_8);
        while (true) {
            System.out.println("\n1. Зашифровать\n2. Расшифровать по ключу\n3. Brute force\n"
                    + "4. Статистический анализ\n0. Выход");
            System.out.print("Режим: ");
            String choice = sc.nextLine().trim();
            try {
                switch (choice) {
                    case "1" -> {
                        Path in = askPath(sc, "Исходный файл: ");
                        checkInput(in);
                        Path out = askPath(sc, "Файл результата: ");
                        processFile(in, out, askKey(sc));
                        System.out.println("Готово: " + out.toAbsolutePath());
                    }
                    case "2" -> {
                        Path in = askPath(sc, "Зашифрованный файл: ");
                        checkInput(in);
                        Path out = askPath(sc, "Файл результата: ");
                        processFile(in, out, -askKey(sc));
                        System.out.println("Готово: " + out.toAbsolutePath());
                    }
                    case "3" -> {
                        Path in = askPath(sc, "Зашифрованный файл: ");
                        checkInput(in);
                        Path out = askPath(sc, "Файл результата: ");
                        String head;
                        try (Stream<String> lines = Files.lines(in, StandardCharsets.UTF_8)) {
                            head = lines.limit(3).collect(Collectors.joining(" "));
                        }
                        if (head.length() > 150) {
                            head = head.substring(0, 150);
                        }
                        for (int key = 0; key < N; key++) {
                            System.out.println(key + ": " + shift(head, -key));
                        }
                        processFile(in, out, -askKey(sc)); // вводим ключ, который подошёл
                        System.out.println("Готово: " + out.toAbsolutePath());
                    }
                    case "4" -> {
                        Path in = askPath(sc, "Зашифрованный файл: ");
                        checkInput(in);
                        Path out = askPath(sc, "Файл результата: ");
                        int key = statisticalKey(in);
                        processFile(in, out, -key);
                        System.out.println("ключ " + key + ". Готово: " + out.toAbsolutePath());
                    }
                    case "0" -> {
                        return;
                    }
                    default -> System.out.println("Нет такого пункта");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Ошибка: " + e.getMessage());
            } catch (IOException e) {
                System.out.println("Ошибка файла: " + e.getMessage());
            }
        }
    }
}