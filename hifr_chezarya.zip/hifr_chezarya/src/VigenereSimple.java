import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;
import java.util.stream.Stream;

public class VigenereSimple {

    static final int N = 26;

    static String process(String text, String key, boolean encrypt, int[] keyPos) {
        StringBuilder sb = new StringBuilder();
        for (char c : text.toCharArray()) {
            char base;
            if (c >= 'A' && c <= 'Z') {
                base = 'A';
            } else if (c >= 'a' && c <= 'z') {
                base = 'a';
            } else {
                sb.append(c);
                continue;
            }
            int shift = Character.toUpperCase(key.charAt(keyPos[0] % key.length())) - 'A';
            if (!encrypt) {
                shift = -shift;
            }
            sb.append((char) (base + Math.floorMod(c - base + shift, N)));
            keyPos[0]++;
        }
        return sb.toString();
    }

    static String encrypt(String text, String key) {
        checkKey(key);
        return process(text, key, true, new int[]{0});
    }

    static String decrypt(String text, String key) {
        checkKey(key);
        return process(text, key, false, new int[]{0});
    }

    static void processFile(Path in, Path out, String key, boolean encrypt) throws IOException {
        checkKey(key);
        int[] keyPos = {0};
        try (Stream<String> lines = Files.lines(in, StandardCharsets.UTF_8)) {
            Files.write(out,
                    (Iterable<String>) lines.map(line -> process(line, key, encrypt, keyPos))::iterator,
                    StandardCharsets.UTF_8);
        }
    }

    static void checkKey(String key) {
        if (key == null || key.isEmpty()) {
            throw new IllegalArgumentException("ключ не должен быть пустым");
        }
        for (char c : key.toCharArray()) {
            if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))) {
                throw new IllegalArgumentException("только английские букв: " + key);
            }
        }
    }

    static void checkInput(Path in) {
        if (!Files.exists(in)) {
            throw new IllegalArgumentException("файл не найден: " + in.toAbsolutePath());
        }
        if (!Files.isRegularFile(in)) {
            throw new IllegalArgumentException("Это не файл: " + in);
        }
    }

    static Path askPath(Scanner sc, String question) {
        System.out.print(question);
        return Path.of(sc.nextLine().trim().replace("\"", ""));
    }

    static String askKey(Scanner sc) {
        System.out.print("ключ (английские буквы): ");
        return sc.nextLine().trim();
    }


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in, StandardCharsets.UTF_8);
        while (true) {
            System.out.println("\n1. Зашифровать файл\n2. Расшифровать файл\n0. Выход");
            System.out.print("Режим: ");
            String choice = sc.nextLine().trim();
            try {
                switch (choice) {
                    case "1", "2" -> {
                        boolean enc = choice.equals("1");
                        Path in = askPath(sc, enc ? "Файл с исходным текстом: " : "Файл с шифртекстом: ");
                        checkInput(in);
                        Path out = askPath(sc, "Файл для результата: ");
                        String key = askKey(sc);
                        processFile(in, out, key, enc);
                        System.out.println("Готово: " + out.toAbsolutePath());
                    }
                    case "0" -> {
                        return;
                    }
                    default -> System.out.println();
                }
            } catch (IllegalArgumentException e) {
                System.out.println();
            } catch (IOException e) {
                System.out.println();
            }
        }
    }
}