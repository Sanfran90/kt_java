import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.Callable;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CipherGUI extends JFrame {

    private final JTextArea log = new JTextArea(6, 50);

    public CipherGUI() {
        super("Шифры");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Цезарь", buildCaesarTab());
        tabs.addTab("Виженер", buildVigenereTab());

        log.setEditable(false);
        log.setLineWrap(true);

        add(tabs, BorderLayout.CENTER);
        add(new JScrollPane(log), BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(null);
    }

    private JPanel buildCaesarTab() {
        FileField in = new FileField(true);
        FileField out = new FileField(false);
        JSpinner keySpinner = new JSpinner(new SpinnerNumberModel(3, -1_000_000, 1_000_000, 1));

        JRadioButton encrypt = new JRadioButton("Шифровать", true);
        JRadioButton decrypt = new JRadioButton("Расшифровать");
        JRadioButton brute = new JRadioButton("Brute force");
        JRadioButton stat = new JRadioButton("Статистика");
        ButtonGroup group = new ButtonGroup();
        JPanel modes = new JPanel(new GridLayout(0, 2));
        for (JRadioButton b : new JRadioButton[]{encrypt, decrypt, brute, stat}) {
            group.add(b);
            modes.add(b);
            b.addActionListener(e -> keySpinner.setEnabled(encrypt.isSelected() || decrypt.isSelected()));
        }

        JButton run = new JButton("Выполнить");
        run.addActionListener(e -> {
            try {
                Path inP = in.path();
                CaesarSimple.checkInput(inP);
                Path outP = out.path();
                int key = (Integer) keySpinner.getValue();

                if (encrypt.isSelected()) {
                    runTask(() -> {
                        CaesarSimple.processFile(inP, outP, key);
                        return done(outP, "Зашифровано");
                    });
                } else if (decrypt.isSelected()) {
                    runTask(() -> {
                        CaesarSimple.processFile(inP, outP, -key);
                        return done(outP, "Расшифровано");
                    });
                } else if (stat.isSelected()) {
                    runTask(() -> {
                        int found = CaesarSimple.statisticalKey(inP);
                        CaesarSimple.processFile(inP, outP, -found);
                        return done(outP, "Ключ " + found);
                    });
                } else {
                    bruteForce(inP, outP);
                }
            } catch (IllegalArgumentException ex) {
                showError(ex.getMessage());
            }
        });

        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        addRow(p, 0, "Исходный файл:", in);
        addRow(p, 1, "Файл результата:", out);
        addRow(p, 2, "Ключ:", keySpinner);
        addRow(p, 3, "Режим:", modes);
        addRow(p, 4, "", run);
        return p;
    }

    private void bruteForce(Path inP, Path outP) {
        String head;
        try (Stream<String> lines = Files.lines(inP, StandardCharsets.UTF_8)) {
            head = lines.limit(3).collect(Collectors.joining(" "));
        } catch (IOException | RuntimeException ex) {
            showError(ex.getMessage());
            return;
        }
        if (head.length() > 120) {
            head = head.substring(0, 120);
        }

        DefaultListModel<String> model = new DefaultListModel<>();
        for (int key = 0; key < CaesarSimple.N; key++) {
            model.addElement(key + ": " + CaesarSimple.shift(head, -key));
        }
        JList<String> list = new JList<>(model);
        list.setSelectedIndex(0);
        JScrollPane pane = new JScrollPane(list);
        pane.setPreferredSize(new Dimension(650, 260));

        int answer = JOptionPane.showConfirmDialog(this, pane, "Brute force",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (answer != JOptionPane.OK_OPTION || list.getSelectedIndex() < 0) {
            return;
        }
        int key = list.getSelectedIndex();
        runTask(() -> {
            CaesarSimple.processFile(inP, outP, -key);
            return done(outP, "Ключ " + key);
        });
    }

    private JPanel buildVigenereTab() {
        FileField in = new FileField(true);
        FileField out = new FileField(false);
        JTextField key = new JTextField(20);

        JRadioButton encrypt = new JRadioButton("Шифровать", true);
        JRadioButton decrypt = new JRadioButton("Расшифровать");
        ButtonGroup group = new ButtonGroup();
        group.add(encrypt);
        group.add(decrypt);
        JPanel modes = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        modes.add(encrypt);
        modes.add(decrypt);

        JButton run = new JButton("Выполнить");
        run.addActionListener(e -> {
            try {
                Path inP = in.path();
                VigenereSimple.checkInput(inP);
                Path outP = out.path();
                String k = key.getText().trim();
                VigenereSimple.checkKey(k);
                boolean enc = encrypt.isSelected();

                runTask(() -> {
                    VigenereSimple.processFile(inP, outP, k, enc);
                    return done(outP, enc ? "Зашифровано" : "Расшифровано");
                });
            } catch (IllegalArgumentException ex) {
                showError(ex.getMessage());
            }
        });

        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        addRow(p, 0, "Исходный файл:", in);
        addRow(p, 1, "Файл результата:", out);
        addRow(p, 2, "Ключ:", key);
        addRow(p, 3, "Режим:", modes);
        addRow(p, 4, "", run);
        return p;
    }

    private void runTask(Callable<String> task) {
        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() throws Exception {
                return task.call();
            }

            @Override
            protected void done() {
                try {
                    log.append(get() + "\n");
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() != null ? ex.getCause() : ex;
                    showError(cause.getMessage());
                }
            }
        }.execute();
    }

    private static String done(Path out, String text) {
        return text + ": " + out.toAbsolutePath();
    }

    private void showError(String message) {
        log.append("Ошибка: " + message + "\n");
        JOptionPane.showMessageDialog(this, message, "Ошибка", JOptionPane.ERROR_MESSAGE);
    }

    private static void addRow(JPanel p, int row, String label, JComponent c) {
        GridBagConstraints g = new GridBagConstraints();
        g.gridy = row;
        g.insets = new Insets(4, 4, 4, 4);
        g.anchor = GridBagConstraints.WEST;
        g.gridx = 0;
        p.add(new JLabel(label), g);
        g.gridx = 1;
        g.weightx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        p.add(c, g);
    }

    static class FileField extends JPanel {
        private final JTextField field = new JTextField(32);

        FileField(boolean open) {
            super(new BorderLayout(5, 0));
            JButton browse = new JButton("Обзор...");
            browse.addActionListener(e -> {
                JFileChooser chooser = new JFileChooser(new File("."));
                int result = open ? chooser.showOpenDialog(this) : chooser.showSaveDialog(this);
                if (result == JFileChooser.APPROVE_OPTION) {
                    field.setText(chooser.getSelectedFile().getAbsolutePath());
                }
            });
            add(field, BorderLayout.CENTER);
            add(browse, BorderLayout.EAST);
        }

        Path path() {
            String s = field.getText().trim().replace("\"", "");
            if (s.isEmpty()) {
                throw new IllegalArgumentException("Путь к файлу не указан");
            }
            return Path.of(s);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
            }
            new CipherGUI().setVisible(true);
        });
    }
}