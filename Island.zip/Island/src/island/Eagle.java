package island;

public class Eagle extends Predator {
    public Eagle() {
        super(Species.EAGLE);
    }
}
