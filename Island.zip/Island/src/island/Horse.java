package island;

public class Horse extends Herbivore {
    public Horse() {
        super(Species.HORSE);
    }
}
