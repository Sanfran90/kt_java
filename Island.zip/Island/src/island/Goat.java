package island;

public class Goat extends Herbivore {
    public Goat() {
        super(Species.GOAT);
    }
}
