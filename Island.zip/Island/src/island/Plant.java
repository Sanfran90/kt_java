package island;

public final class Plant {
    public static final double WEIGHT = 1.0;
    public static final int MAX_PER_CELL = 200;
    public static final String EMOJI = "🌿";

    private Plant() {}
}
