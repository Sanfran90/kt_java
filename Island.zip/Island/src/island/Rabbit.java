package island;

public class Rabbit extends Herbivore {
    public Rabbit() {
        super(Species.RABBIT);
    }
}
