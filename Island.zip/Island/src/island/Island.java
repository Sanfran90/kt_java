package island;

import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public class Island {
    private final int width;
    private final int height;
    private final Location[][] grid;

    public Island(int width, int height) {
        this.width = width;
        this.height = height;
        this.grid = new Location[width][height];
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                grid[x][y] = new Location(x, y);
            }
        }
    }

    public int getWidth() { return width; }
    public int getHeight() { return height; }

    public boolean inBounds(int x, int y) {
        return x >= 0 && y >= 0 && x < width && y < height;
    }

    public Location at(int x, int y) {
        return grid[x][y];
    }

    /** Начальное заселение: растения и животные в случайных клетках. */
    public void populate() {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                grid[x][y].growPlants((int) (rnd.nextDouble() * Plant.MAX_PER_CELL * Config.INITIAL_PLANTS_FILL * 2));
            }
        }
        for (Species s : Species.values()) {
            int n = Config.START_COUNT.getOrDefault(s, 0);
            int placed = 0;
            int attempts = 0;
            while (placed < n && attempts < n * 20) {
                attempts++;
                Location loc = grid[rnd.nextInt(width)][rnd.nextInt(height)];
                if (loc.add(s.create())) placed++;
            }
        }
    }

    /** Снимок статистики: сколько животных каждого вида и сколько растений. */
    public Stats collectStats() {
        Map<Species, Integer> counts = new EnumMap<>(Species.class);
        long plants = 0;
        for (Species s : Species.values()) counts.put(s, 0);
        for (Location[] column : grid) {
            for (Location loc : column) {
                loc.lock.lock();
                try {
                    plants += (long) loc.getPlants();
                    for (Species s : Species.values()) {
                        counts.merge(s, loc.count(s), Integer::sum);
                    }
                } finally {
                    loc.lock.unlock();
                }
            }
        }
        return new Stats(counts, plants);
    }

    public record Stats(Map<Species, Integer> counts, long plants) {
        public int totalAnimals() {
            return counts.values().stream().mapToInt(Integer::intValue).sum();
        }
    }
}
