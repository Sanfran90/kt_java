package island;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.locks.ReentrantLock;

public class Location {
    public final int x;
    public final int y;
    public final ReentrantLock lock = new ReentrantLock();

    private final Map<Species, List<Animal>> animals = new EnumMap<>(Species.class);
    private double plants;

    public Location(int x, int y) {
        this.x = x;
        this.y = y;
        for (Species s : Species.values()) {
            animals.put(s, new ArrayList<>());
        }
    }

    // ---- животные

    public int count(Species s) {
        return animals.get(s).size();
    }

    public boolean add(Animal a) {
        List<Animal> list = animals.get(a.species);
        if (list.size() >= a.species.maxPerCell) return false;
        a.moving = false;
        list.add(a);
        return true;
    }

    public Animal takeRandom(Species s) {
        List<Animal> list = animals.get(s);
        if (list.isEmpty()) return null;
        int i = ThreadLocalRandom.current().nextInt(list.size());
        Animal victim = list.get(i);
        int last = list.size() - 1;
        list.set(i, list.get(last));
        list.remove(last);
        return victim;
    }

    public boolean hasMale(Species s) {
        for (Animal a : animals.get(s)) {
            if (!a.female && a.alive) return true;
        }
        return false;
    }

    public List<Animal> snapshot() {
        List<Animal> all = new ArrayList<>();
        for (List<Animal> list : animals.values()) all.addAll(list);
        return all;
    }

    public void removeDeadAndLeaving() {
        for (List<Animal> list : animals.values()) {
            list.removeIf(a -> !a.alive || a.moving);
        }
    }

    // ---- растения

    public double getPlants() {
        return plants;
    }

    public void growPlants(int amount) {
        plants = Math.min(Plant.MAX_PER_CELL, plants + amount);
    }

    public double takePlants(double kg) {
        double eaten = Math.min(kg, plants);
        plants -= eaten;
        return eaten;
    }
}
