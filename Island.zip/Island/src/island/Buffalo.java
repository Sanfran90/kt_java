package island;

public class Buffalo extends Herbivore {
    public Buffalo() {
        super(Species.BUFFALO);
    }
}
