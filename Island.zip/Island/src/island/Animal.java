package island;

import java.util.concurrent.ThreadLocalRandom;

public abstract class Animal {
    private static final Species[] ALL = Species.values();

    protected final Species species;
    protected final boolean female;

    protected double satiety;

    boolean alive = true;

    boolean moving;

    long lastTick = -1;

    protected Animal(Species species) {
        this.species = species;
        this.female = ThreadLocalRandom.current().nextBoolean();
        this.satiety = species.foodNeeded * 0.5; // стартуем наполовину сытыми
    }

    public Species getSpecies() {
        return species;
    }

    public abstract void eat(Location loc);

    protected boolean isFull() {
        return satiety >= species.foodNeeded - 1e-9;
    }

    protected void gain(double kg) {
        satiety = Math.min(species.foodNeeded, satiety + kg);
    }

    protected void huntAnimals(Location loc) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        int start = rnd.nextInt(ALL.length);
        for (int i = 0; i < ALL.length && !isFull(); i++) {
            Species prey = ALL[(start + i) % ALL.length];
            if (prey == species) continue;
            int chance = EatTable.chance(species, prey);
            if (chance > 0 && rnd.nextInt(100) < chance) {
                Animal victim = loc.takeRandom(prey);
                if (victim != null) {
                    victim.alive = false;
                    gain(prey.weight);
                }
            }
        }
    }

    public boolean starve() {
        if (species.foodNeeded <= 0) return true; // гусеницы не голодают
        satiety -= species.foodNeeded * Config.HUNGER_RATE;
        if (satiety <= 0) alive = false;
        return alive;
    }

    public int reproduce(Location loc, long tick) {
        if (!female || !alive) return 0;
        int free = species.maxPerCell - loc.count(species);
        if (free <= 0 || satiety < species.foodNeeded * 0.5) return 0; // голодные не размножаются
        if (!loc.hasMale(species)) return 0;
        // чем теснее в клетке, тем реже рождаются детёныши
        double crowding = 1.0 - (double) loc.count(species) / species.maxPerCell;
        if (ThreadLocalRandom.current().nextDouble() >= Config.BIRTH_CHANCE * crowding) return 0;
        int babies = Math.min(Config.litter(species), free);
        for (int i = 0; i < babies; i++) {
            Animal baby = species.create();
            baby.lastTick = tick; // новорождённый в этом такте не ходит
            loc.add(baby);
        }
        return babies;
    }

    public Direction chooseDirection() {
        Direction[] d = Direction.values();
        return d[ThreadLocalRandom.current().nextInt(d.length)];
    }

    public Location move(Island island, Location from) {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        if (species.speed == 0 || rnd.nextDouble() >= Config.MOVE_CHANCE) return from;
        int steps = 1 + rnd.nextInt(species.speed);
        int x = from.x;
        int y = from.y;
        for (int i = 0; i < steps; i++) {
            Direction d = chooseDirection();
            int nx = x + d.dx;
            int ny = y + d.dy;
            if (island.inBounds(nx, ny)) { // за границу острова не выходим
                x = nx;
                y = ny;
            }
        }
        return island.at(x, y);
    }
}
