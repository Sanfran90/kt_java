package island;

public class Sheep extends Herbivore {
    public Sheep() {
        super(Species.SHEEP);
    }
}
