package island;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        for (String arg : args) {
            String[] kv = arg.split("=", 2);
            if (kv.length != 2) continue;
            switch (kv[0]) {
                case "width" -> Config.WIDTH = Integer.parseInt(kv[1]);
                case "height" -> Config.HEIGHT = Integer.parseInt(kv[1]);
                case "tick" -> Config.TICK_MS = Long.parseLong(kv[1]);
                case "maxTicks" -> Config.MAX_TICKS = Long.parseLong(kv[1]);
                default -> System.out.println("Неизвестный параметр: " + kv[0]);
            }
        }
        new Simulation().run();
    }
}
