package island;

import java.util.EnumMap;
import java.util.Map;

public final class Config {
    private Config() {}

    public static int WIDTH = 100;
    public static int HEIGHT = 20;
    public static long TICK_MS = 1000;
    public static long MAX_TICKS = 0;

    public static double HUNGER_RATE = 0.1;
    public static double MOVE_CHANCE = 0.8;
    public static double BIRTH_CHANCE = 0.2;

    public static double INITIAL_PLANTS_FILL = 0.5;
    public static int PLANT_GROWTH_MAX = 3;

    public static final Map<Species, Integer> START_COUNT = new EnumMap<>(Species.class);
    public static final Map<Species, Integer> LITTER = new EnumMap<>(Species.class);

    static {
        start(Species.WOLF, 60);
        start(Species.BOA, 60);
        start(Species.FOX, 70);
        start(Species.BEAR, 15);
        start(Species.EAGLE, 70);
        start(Species.HORSE, 100);
        start(Species.DEER, 100);
        start(Species.RABBIT, 400);
        start(Species.MOUSE, 400);
        start(Species.GOAT, 200);
        start(Species.SHEEP, 200);
        start(Species.BOAR, 80);
        start(Species.BUFFALO, 40);
        start(Species.DUCK, 300);
        start(Species.CATERPILLAR, 600);

        litter(Species.WOLF, 2);
        litter(Species.BOA, 2);
        litter(Species.FOX, 2);
        litter(Species.BEAR, 1);
        litter(Species.EAGLE, 2);
        litter(Species.HORSE, 1);
        litter(Species.DEER, 1);
        litter(Species.RABBIT, 3);
        litter(Species.MOUSE, 2);
        litter(Species.GOAT, 2);
        litter(Species.SHEEP, 2);
        litter(Species.BOAR, 2);
        litter(Species.BUFFALO, 1);
        litter(Species.DUCK, 2);
        litter(Species.CATERPILLAR, 3);
    }

    private static void start(Species s, int n) {
        START_COUNT.put(s, n);
    }

    private static void litter(Species s, int n) {
        LITTER.put(s, n);
    }

    public static int litter(Species s) {
        return LITTER.getOrDefault(s, 1);
    }
}
