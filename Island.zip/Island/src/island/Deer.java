package island;

public class Deer extends Herbivore {
    public Deer() {
        super(Species.DEER);
    }
}
