package island;

public class Wolf extends Predator {
    public Wolf() {
        super(Species.WOLF);
    }
}
