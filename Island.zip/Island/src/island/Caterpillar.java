package island;

public class Caterpillar extends Herbivore {
    public Caterpillar() {
        super(Species.CATERPILLAR);
    }
}
