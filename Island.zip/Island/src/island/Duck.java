package island;

public class Duck extends Herbivore {
    public Duck() {
        super(Species.DUCK);
    }

    @Override
    public void eat(Location loc) {
        eatPlants(loc);
        huntAnimals(loc); // особенность вида: добавляет животную пищу
    }
}
