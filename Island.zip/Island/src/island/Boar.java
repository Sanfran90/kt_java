package island;

public class Boar extends Herbivore {
    public Boar() {
        super(Species.BOAR);
    }

    @Override
    public void eat(Location loc) {
        eatPlants(loc);
        huntAnimals(loc); // особенность вида: добавляет животную пищу
    }
}
