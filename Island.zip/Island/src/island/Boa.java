package island;

public class Boa extends Predator {
    public Boa() {
        super(Species.BOA);
    }
}
