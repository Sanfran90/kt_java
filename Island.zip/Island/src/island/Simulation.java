package island;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;


public class Simulation {
    private final Island island = new Island(Config.WIDTH, Config.HEIGHT);
    private final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(3);
    private final ExecutorService workers =
            Executors.newFixedThreadPool(Math.max(2, Runtime.getRuntime().availableProcessors()));
    private final AtomicLong tick = new AtomicLong();

    public void run() throws InterruptedException {
        island.populate();
        System.out.printf("Остров %dx%d, такт = %d мс%n", Config.WIDTH, Config.HEIGHT, Config.TICK_MS);
        printStats();

        long period = Config.TICK_MS;
        scheduler.scheduleAtFixedRate(guard(this::growPlants), period, period, TimeUnit.MILLISECONDS);
        scheduler.scheduleAtFixedRate(guard(this::lifeCycle), period, period, TimeUnit.MILLISECONDS);
        // статистика чуть позже жизненного цикла, чтобы печатать итог такта
        scheduler.scheduleAtFixedRate(guard(this::statsTask), period + period / 2, period, TimeUnit.MILLISECONDS);

        while (!scheduler.awaitTermination(1, TimeUnit.SECONDS)) {
            // ждём остановки
        }
        workers.shutdown();
        workers.awaitTermination(5, TimeUnit.SECONDS);
        System.out.println("Симуляция остановлена.");
    }

    /** Исключение в периодической задаче молча отменяет её, поэтому ловим и печатаем. */
    private Runnable guard(Runnable r) {
        return () -> {
            try {
                r.run();
            } catch (Throwable t) {
                t.printStackTrace();
            }
        };
    }

    // ------------------------------------------------------------- рост растений

    private void growPlants() {
        ThreadLocalRandom rnd = ThreadLocalRandom.current();
        for (int x = 0; x < island.getWidth(); x++) {
            for (int y = 0; y < island.getHeight(); y++) {
                Location loc = island.at(x, y);
                loc.lock.lock();
                try {
                    loc.growPlants(rnd.nextInt(Config.PLANT_GROWTH_MAX + 1));
                } finally {
                    loc.lock.unlock();
                }
            }
        }
    }

    // ------------------------------------------------------ жизненный цикл животных

    private void lifeCycle() {
        long t = tick.incrementAndGet();
        List<Callable<Void>> tasks = new ArrayList<>();
        for (int x = 0; x < island.getWidth(); x++) {
            for (int y = 0; y < island.getHeight(); y++) {
                Location loc = island.at(x, y);
                tasks.add(() -> {
                    processCell(loc, t);
                    return null;
                });
            }
        }
        try {
            workers.invokeAll(tasks); // ждём, пока обработаются все клетки
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private record Move(Animal animal, Location target) {}

    /** Один такт для одной клетки: поесть -> размножиться -> проголодаться -> переместиться. */
    private void processCell(Location cell, long t) {
        List<Move> moves = new ArrayList<>();
        cell.lock.lock();
        try {
            List<Animal> animals = cell.snapshot();
            Collections.shuffle(animals, ThreadLocalRandom.current());

            List<Animal> active = new ArrayList<>(animals.size());
            for (Animal a : animals) {
                if (!a.alive || a.lastTick == t) continue; // съеден или уже ходил в этом такте
                a.lastTick = t;
                a.eat(cell);
                a.reproduce(cell, t);
                active.add(a);
            }
            for (Animal a : active) {
                if (!a.alive || !a.starve()) continue; // съеден по ходу такта или умер от голода
                Location target = a.move(island, cell);
                if (target != cell) {
                    a.moving = true;
                    moves.add(new Move(a, target));
                }
            }
            cell.removeDeadAndLeaving();
        } finally {
            cell.lock.unlock();
        }

        // Переселение: блокируем только клетку назначения (по одной за раз).
        for (Move m : moves) {
            boolean placed;
            m.target.lock.lock();
            try {
                placed = m.target.add(m.animal);
            } finally {
                m.target.lock.unlock();
            }
            if (!placed) { // в целевой клетке нет места - возвращаемся домой
                cell.lock.lock();
                try {
                    cell.add(m.animal);
                } finally {
                    cell.lock.unlock();
                }
            }
        }
    }

    // ------------------------------------------------------------------ статистика

    private void statsTask() {
        Island.Stats stats = printStats();
        long t = tick.get();
        boolean extinct = stats.totalAnimals() == 0;
        boolean limit = Config.MAX_TICKS > 0 && t >= Config.MAX_TICKS;
        if (extinct || limit) {
            System.out.println(extinct ? "Все животные вымерли." : "Достигнут лимит тактов.");
            scheduler.shutdown(); // отменяет периодические задачи; текущие дорабатывают
        }
    }

    private Island.Stats printStats() {
        Island.Stats stats = island.collectStats();
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Такт %-4d |", tick.get()));
        for (Species s : Species.values()) {
            sb.append(' ').append(s.emoji).append(stats.counts().get(s));
        }
        sb.append(" | ").append(Plant.EMOJI).append(stats.plants());
        sb.append(" | всего животных: ").append(stats.totalAnimals());
        System.out.println(sb);
        return stats;
    }
}
