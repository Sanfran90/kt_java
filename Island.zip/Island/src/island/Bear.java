package island;

public class Bear extends Predator {
    public Bear() {
        super(Species.BEAR);
    }
}
