package island;

public class Mouse extends Herbivore {
    public Mouse() {
        super(Species.MOUSE);
    }

    @Override
    public void eat(Location loc) {
        eatPlants(loc);
        huntAnimals(loc); // особенность вида: добавляет животную пищу
    }
}
