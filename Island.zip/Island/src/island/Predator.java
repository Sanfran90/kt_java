package island;

public abstract class Predator extends Animal {
    protected Predator(Species species) {
        super(species);
    }

    @Override
    public void eat(Location loc) {
        for (int i = 0; i < 3 && !isFull(); i++) { // хищник успевает поохотиться несколько раз за такт
            huntAnimals(loc);
        }
    }
}
