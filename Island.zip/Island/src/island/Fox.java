package island;

public class Fox extends Predator {
    public Fox() {
        super(Species.FOX);
    }
}
