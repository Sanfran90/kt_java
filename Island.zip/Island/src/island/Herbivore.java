package island;

import java.util.concurrent.ThreadLocalRandom;

public abstract class Herbivore extends Animal {
    protected Herbivore(Species species) {
        super(species);
    }

    @Override
    public void eat(Location loc) {
        eatPlants(loc);
    }

    protected void eatPlants(Location loc) {
        if (isFull()) return;
        int chance = EatTable.plantChance(species);
        if (chance <= 0 || ThreadLocalRandom.current().nextInt(100) >= chance) return;
        gain(loc.takePlants(species.foodNeeded - satiety)); // едим столько, сколько нужно до сытости
    }
}
